import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BookService } from '../services/book.service';

@Component({
  selector: 'app-books-details',
  templateUrl: './books-details.component.html',
  styleUrls: ['./books-details.component.scss']
})
export class BooksDetailsComponent implements OnInit {

  bookData: any;

  constructor( private userService: BookService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    let bookId = this.route.snapshot.paramMap.get('id');

    this.userService.getBookById(bookId)
      .subscribe( ( res: any) => {
        console.log(res);
        this.bookData = res;
      });
  }

}
